package com.example.deepak.a2048;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edtxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtxt = (EditText)findViewById(R.id.usuario);
    }

    public void startGame(View v)
    {
        String some = edtxt.getText().toString();
        Intent i=new Intent(this,Game.class);
        i.putExtra("user",some);
        startActivity(i);
    }
    public void score(View v)
    {
        Intent its=new Intent(this,ResultPage.class);
        its.putExtra("Result",1);
        its.putExtra("nomeveo",1);
        startActivity(its);
    }
    public void quit(View v)
    {
        System.exit(0);
    }
}