package com.example.deepak.a2048;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ResultPage extends AppCompatActivity{
    String use;
    int pt,b2;
    TextView r,s;
    Button bot;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        SharedPreferences myPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor myEditor = myPreferences.edit();

        use = getIntent().getStringExtra("name");
        pt = getIntent().getIntExtra("score",0);
        int b2 = getIntent().getIntExtra("nomeveo",0);
        r = findViewById(R.id.ResultTxt);
        s = findViewById(R.id.scoree);
        bot = findViewById(R.id.ResultBtn);
        //ResultTxt
        //scoree
        /*
        if(b2 == 1)
        {
            bot.getText();
            Toast tt = Toast.makeText(getApplicationContext(),bot.getText().toString(),Toast.LENGTH_LONG);
            tt.show();
            bot.setText("Menu Principal");
            r.setVisibility(View.GONE);
            s.setVisibility(View.GONE);
        }
        */
        /*
        myEditor.putString("name1","Lalo");
        myEditor.putString("name2","Aaron");
        myEditor.putString("name3","Beto");
        myEditor.putString("name4","Arturo");
        myEditor.putString("name5","ElBicho");
        myEditor.putInt("pts1",2048);
        myEditor.putInt("pts2",1024);
        myEditor.putInt("pts3",512);
        myEditor.putInt("pts4",256);
        myEditor.putInt("pts5",128);
        myEditor.commit();
        */

        String nombre1 = myPreferences.getString("name1","unkow");
        int puntos1 = myPreferences.getInt("pts1",0);
        String nombre2 = myPreferences.getString("name2","unkow");
        int puntos2 = myPreferences.getInt("pts2",0);
        String nombre3 = myPreferences.getString("name3","unkow");
        int puntos3 = myPreferences.getInt("pts3",0);
        String nombre4 = myPreferences.getString("name4","unkow");
        int puntos4 = myPreferences.getInt("pts4",0);
        String nombre5 = myPreferences.getString("name5","unkow");
        int puntos5 = myPreferences.getInt("pts5",0);

        if(pt > puntos1)
        {
            nombre5 = nombre4;
            puntos5 = puntos4;
            nombre4 = nombre3;
            puntos4 = puntos3;
            nombre3 = nombre2;
            puntos3 = puntos2;
            nombre2 = nombre1;
            puntos2 = puntos1;
            nombre1 = use;
            puntos1 = pt;

        }
        else if(pt > puntos2 && pt < puntos1)
        {
            nombre5 = nombre4;
            puntos5 = puntos4;
            nombre4 = nombre3;
            puntos4 = puntos3;
            nombre3 = nombre2;
            puntos3 = puntos2;
            nombre2 = use;
            puntos2 = pt;
        }
        else if(pt > puntos3 && pt < puntos2)
        {
            nombre5 = nombre4;
            puntos5 = puntos4;
            nombre4 = nombre3;
            puntos4 = puntos3;
            nombre3 = use;
            puntos3 = pt;
        }
        else if(pt > puntos4 && pt < puntos3)
        {
            nombre5 = nombre4;
            puntos5 = puntos4;
            nombre4 = use;
            puntos4 = pt;
        }
        else if(pt > puntos5 && pt < puntos4)
        {
            nombre5 = use;
            puntos5 = pt;
        }

        final ListView milista = (ListView)findViewById(R.id.milista);
        String[] values = new String[]
                {
                        nombre1+": "+puntos1,
                        nombre2+": "+puntos2,
                        nombre3+": "+puntos3,
                        nombre4+": "+puntos4,
                        nombre5+": "+puntos5
                };

        myEditor.putString("name1",nombre1);
        myEditor.putString("name2",nombre2);
        myEditor.putString("name3",nombre3);
        myEditor.putString("name4",nombre4);
        myEditor.putString("name5",nombre5);
        myEditor.putInt("pts1",puntos1);
        myEditor.putInt("pts2",puntos2);
        myEditor.putInt("pts3",puntos3);
        myEditor.putInt("pts4",puntos4);
        myEditor.putInt("pts5",puntos5);
        myEditor.commit();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,values);
        milista.setAdapter(adapter);

        int result= getIntent().getExtras().getInt("Result");
        int scores = getIntent().getIntExtra("score",0);
        Button btn= findViewById(R.id.ResultBtn);
        TextView tv = findViewById(R.id.ResultTxt);
        TextView scres = findViewById(R.id.scoree);
        String b = Integer.toString(scores);
        if(result==0)
        {

            scres.setText(b);
            btn.setText("Menú principal");
            tv.setText("Felicidades, has ganado!");
            if(b2 == 1)
            {
                bot.getText();
                bot.setText("Menu Principal");
                r.setVisibility(View.GONE);
                s.setVisibility(View.GONE);
            }
        }
        else
        {
            scres.setText("Puntuación: " + b);
            tv.setText("Has perdido :c");
            btn.setText("Intenta neuvamente");
            if(b2 == 1)
            {
                bot.getText();
                bot.setText("Menu Principal");
                r.setVisibility(View.GONE);
                s.setVisibility(View.GONE);
            }
        }
    }
    public void retry(View v)
    {
        Intent i= new Intent(ResultPage.this,Game.class);
        System.exit(0);
        startActivity(i);
    }
}
